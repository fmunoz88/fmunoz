Changelog
=========
1.0.5
-----
- [FIXED] Licence file
- [CHANGE] package.json
- [CHANGE] Code Folding extension theme enhanced.

1.0.4
-----

- [NEW] Brackets Css Color Preview extension theme
- [CHANGE] Code Folding extension theme modified, based on (https://github.com/visualbam/Brackets-Stripper)
- [CHANGE] Code documentation and cleaning
- [CHANGE] Licence included in theme file
- [FIXED] Padding bug

1.0.3
-----

- [CHANGE] Requires Brackets 1.0.0 or higher
- [REMOVE] Useless main.js
- [NEW] Code folding extension theme
- [FIXED] Cleaned code & documentation

1.0.2
-----

- [NEW] 0.43 support (.CodeMirror-searching)
- [FIX] Fixed non-editor styles
- [NEW] .CodeMirror-linenumber

1.0.0
-----

- [NEW] Forked from Monokai theme
- [CHANGE] Dark soda theme changes
